# yellow vest > 2024-11-25 9:13pm
https://universe.roboflow.com/neal-c9jwt/yellow-vest-fbkv2

Provided by a Roboflow user
License: CC BY 4.0

